library("tidyverse")
library("survey")
library("PracTools")
library("sf")

pfad <- file.path("G:", "ada_bayern")
pfad <- file.path("/Users/marcelneunhoeffer/LRZ Sync+Share/consulting-archiv/data/ada-bayern-data")
col_types <- c("ccccnccccccccccccccccccTTcnTccnTcTcccc")

forumstar_daten <- read_csv(file.path(pfad, "230817_Abfrage_Januar-Dezember.csv"), col_types = col_types)
karte_amtsgerichte <- readRDS(file.path(pfad, "230911_Karte_Amtsgerichtsbezirke.RDS"))

akten <- forumstar_daten %>%
  group_by(
    `Gericht`,
    `Aktenzeichen`,
    `Streitwert in EURO`,
    `Gesamtstreitgegenstand`,
    `Erledigungsgrund`,
    `Dauer des Verfahrens in Tagen`,
    `Archivstatus`,
    `Anbietungsgrund (manuell erfasst)`,
    `Anbietungsgrund`
  ) %>%
  summarise(`Anzahl Beteiligte` = n()) %>%
  as.data.frame() %>%
  mutate(Index = row_number())


tmp_Gericht <- sub("Amtsgericht ", "", akten$Gericht)
tmp_Gericht <- sub(" Zweigstelle.*", "", tmp_Gericht)
tmp_Gericht <- sub(" i.d. ", " i. d. ", tmp_Gericht)
tmp_Gericht <- sub(" a.d. ", " a. d. ", tmp_Gericht)
tmp_Gericht <- sub(" am ", " a. ", tmp_Gericht)
tmp_Gericht <- sub(" i.OB", " i. OB", tmp_Gericht)

akten <- akten %>%
  mutate(`Bezirk` = tmp_Gericht)
